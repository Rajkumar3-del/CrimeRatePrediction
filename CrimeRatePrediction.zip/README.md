# Crime Rate Prediction (Java + SQL + Simple ML)
This project predicts future crime rates using simple linear regression with Java and MySQL.
